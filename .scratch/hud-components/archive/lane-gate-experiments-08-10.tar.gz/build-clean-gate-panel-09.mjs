// Run from repo root. A deterministic fallback/comparison for the Meshy plate.
import fs from 'node:fs'
import * as THREE from '../../frontend/node_modules/three/build/three.module.js'
const shape = new THREE.Shape()
shape.moveTo(-0.45, -0.5)
shape.lineTo(0.5, 0)
shape.lineTo(-0.45, 0.5)
shape.closePath()
const geometry = new THREE.ExtrudeGeometry(shape, {
  depth: 0.025, steps: 1, bevelEnabled: true, bevelThickness: 0.004,
  bevelSize: 0.004, bevelSegments: 1, curveSegments: 1,
})
geometry.translate(0, 0, -0.0125)
const attributes = ['position', 'normal'].map(name => geometry.getAttribute(name))
const buffers = attributes.map(a => Buffer.from(a.array.buffer, a.array.byteOffset, a.array.byteLength))
geometry.computeBoundingBox()
const doc = {
  asset: { version: '2.0', generator: 'Hexaverse explicit triangular plate 09' },
  scene: 0, scenes: [{ nodes: [0] }], nodes: [{ name: 'TriangularPlate', mesh: 0 }],
  meshes: [{ name: 'TriangularPlate', primitives: [{ attributes: { POSITION: 0, NORMAL: 1 }, material: 0 }] }],
  materials: [{ name: 'manufactured-01_primary-surface', pbrMetallicRoughness: { baseColorFactor: [0.58, 0.61, 0.65, 1], metallicFactor: 0.6, roughnessFactor: 0.42 } }],
  accessors: attributes.map((a, i) => ({ bufferView: i, componentType: 5126, count: a.count, type: 'VEC3', ...(i === 0 ? { min: geometry.boundingBox.min.toArray(), max: geometry.boundingBox.max.toArray() } : {}) })),
  bufferViews: buffers.map((b, i) => ({ buffer: 0, byteOffset: i ? buffers[0].length : 0, byteLength: b.length, target: 34962 })),
  buffers: [{ byteLength: buffers.reduce((n, b) => n + b.length, 0) }],
  extras: { styleProfile: 'manufactured-01', styleRevision: 1, construction: 'One triangular prism with flat parallel faces, uniform thickness and one-segment perimeter bevel. Separate kit part; no surface machinery.' },
}
let json = Buffer.from(JSON.stringify(doc))
json = Buffer.concat([json, Buffer.alloc((4 - json.length % 4) % 4, 32)])
const binary = Buffer.concat(buffers), header = Buffer.alloc(20), chunk = Buffer.alloc(8)
header.writeUInt32LE(0x46546c67); header.writeUInt32LE(2, 4); header.writeUInt32LE(28 + json.length + binary.length, 8)
header.writeUInt32LE(json.length, 12); header.writeUInt32LE(0x4e4f534a, 16)
chunk.writeUInt32LE(binary.length); chunk.writeUInt32LE(0x004e4942, 4)
const output = Buffer.concat([header, json, chunk, binary])
for (const path of ['.scratch/hud-components/lane-gate-panel-clean-09.glb', 'frontend/public/models/space/lane-gate-panel-clean-09.glb']) fs.writeFileSync(path, output)
// A closed part has exactly two triangle edges incident on every welded edge.
const welded = new Map(), ids = []
for (let i = 0; i < attributes[0].count; i++) {
  const key = [0, 1, 2].map(a => attributes[0].array[i * 3 + a].toFixed(6)).join(',')
  if (!welded.has(key)) welded.set(key, welded.size)
  ids.push(welded.get(key))
}
const edges = new Map()
for (let i = 0; i < ids.length; i += 3) for (const [a, b] of [[ids[i], ids[i + 1]], [ids[i + 1], ids[i + 2]], [ids[i + 2], ids[i]]]) {
  const key = [a, b].sort((a, b) => a - b).join(',')
  edges.set(key, (edges.get(key) ?? 0) + 1)
}
const bad = [...edges.values()].filter(n => n !== 2).length
if (bad) throw new Error(`${bad} invalid boundary edges`)
console.log(JSON.stringify({ triangles: attributes[0].count / 3, weldedVertices: welded.size, boundaryEdges: 0, nonManifoldEdges: 0 }))
geometry.dispose()
