# Modular lane gate 10

Travis authorized constructing all parts and assembling the gate after the
round 09 comparison. Uses explicit geometry, not the rejected Meshy part.
Style: manufactured-01 revision 1. Gate-specific construction revision; shared
family art direction is unchanged. No Meshy credits spent in this round.

## Construction

Eight broad beveled triangular plates (four per half), graphite backing frames,
metal perimeter rails, upper/lower spines, collars, two-sided connector covers,
hexagonal fasteners, amber utility windows and narrow pale blue emitter strips.
Front and back have the same restrained detail. Emitter strips sit on metal
spine caps. Every component remains an individually named closed mesh node.
Geometry and materials are reused between matching instances.

126 mesh instances, 23 distinct mesh definitions, 2,120 rendered triangles,
54,648-byte GLB. Materials have separate semantic roles: primary surface,
structural recess, edge metal, utility accent and energy. No baked textures,
random surface relief, rear braces or connecting machinery between halves.

Two rigid parent groups, LeftHalf and RightHalf, with a 1.5-second Open clip.
Root translations range from +/-0.006 to +/-0.35; the mesh geometry leaves
additional inset clearance, so measured apertures are 0.028 closed and 0.716
open. Right half uses a proper 180-degree rotation rather than negative scale.
Default pose is open. Portal field remains a separate future effect.

## Artifacts and reproduction

Run from repository root:

    node .scratch/hud-components/build-modular-lane-gate-10.mjs

The builder writes archived and served copies of:

- `lane-gate-modular-10.glb`: whole animated assembly.
- `lane-gate-parts-10.glb`: nine representative kit components for inspection.
- `lane-gate-exploded-10.glb`: one half with plates lifted away from backing.

Served files are in `frontend/public/models/space/`. Original `lane-gate.glb`
is preserved as the round 07 comparison. No world integration or production
thumbnail replacement is included in this art revision.

## Review and validation

Storybook Graphics / Model View has Modular Gate, Modular Gate Back, Modular
Gate Side, Modular Gate Closed, Modular Gate Opening, Gate Parts and Exploded
Gate Half. Existing view, orbit, progress, playing and wireframe controls apply.

Builder verifies every part has exactly two incident triangle edges at each
welded edge: no open boundaries or non-manifold edges. It also checks rigid-half
clearance at three opening positions. Independent GLTFLoader decoding verifies
126 parts, Open clip with two translation tracks and the measured aperture at
0, 0.75 and 1.5 seconds. See `lane-gate-modular-10.review.json` and stats JSON.
All six static browser review views rendered without page errors; screenshots
are preserved alongside this record. Story file ESLint and per-file validation
pass. Visual review uses the browser's available renderer backend; native
WebGPU is not independently certified by these captures.

The assembled asset is ready for Travis's visual review. Its surfaces are
intentionally plain, with geometry and material-role separation ready for
further art refinement without reworking an opaque generated mesh.

## User feedback

Travis finds this cleaner but less realistic and less dimensional than the
original generated Raw GLB. Small artifacts are acceptable at gameplay distance.
Keep this build as a construction reference; prefer round 07 for visual work.
