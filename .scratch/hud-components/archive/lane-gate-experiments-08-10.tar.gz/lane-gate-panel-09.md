# Lane gate modular panel test 09

Style: manufactured-01 revision 1. Object-specific construction experiment;
no shared style change. Original round 07 gate remains the comparison asset.

## Decision

Travis approved trying a modular kit: generate one isolated triangular plate,
inspect untextured geometry, duplicate accepted parts, construct simple rails
and connectors directly, then apply consistent materials and group two halves.
The first checkpoint is the individual plate, not another whole-gate generation.

Round 08 scripted rear-shell experiments were rejected: cutting/mirroring the
generated trim produced seam and edge artifacts. The served lane-gate.glb was
restored byte-for-byte from lane-gate-model-07.glb. Round 08 is not production.

## First part

One plain scalene triangular prism, flat parallel faces, uniform thin depth and
small bevels. No rails, bolts, lights, pipes, seams or decorative surface detail.
Those are separate kit components. Built-in image generation creates the
isolated reference; Meshy T2 Smart Topology generates geometry only, 500 target
triangles, GLB. The test costs 5 Meshy credits from the existing 50-credit gate
budget (30 spent before this test). No texturing or automatic paid retry.

Geometry review: front, back, side, orbit and wireframe using the existing
Graphics / Model View Storybook foundation. Check straight edges, flat broad
faces, consistent thickness, closed shell and unwanted fragments before using
the part in an assembly.

## Results

- Meshy task: `01a141e6-6793-7766-959a-a986f48d2c91`, SUCCEEDED,
  5 credits. Gate spending now 35/50, remaining 15. Balance before test 2,693.
- Raw reference: `lane-gate-panel-reference-09.png`, generated with built-in
  image_gen, transparent_background=true and round 07 reference as style input.
- Raw geometry: `lane-gate-panel-generated-09.glb`, 539 triangles, 281 vertices,
  one connected component. No textures, normals or material supplied by Meshy.
- Geometry review: broad faces are clean but side view reveals holes. After
  welding coincident positions to six decimals: 28 open boundary edges and one
  non-manifold edge. Not accepted for assembly. See `lane-gate-panel-09.review.json`.
- Served comparison: `/models/space/lane-gate-panel-09.glb`; Storybook
  `graphics-model-view--gate-panel`, with Back, Side and Wireframe variants.
- Fallback comparison built from explicit geometry:
  `lane-gate-panel-clean-09.glb`, 20 triangles, 12 welded vertices, zero open or
  non-manifold edges. Uniform depth 0.025 plus 0.004 front/rear bevels, gray
  metallic primary-surface material. Reproduce with
  `node .scratch/hud-components/build-clean-gate-panel-09.mjs`.
- Clean comparison: `graphics-model-view--clean-gate-panel`; view and wireframe
  controls support the same inspection. Front/rear/side screenshots preserved.
- Browser review: all generated-panel stories and all three clean-panel views
  loaded without page errors. Story file ESLint passes. Topology closure checked
  in the clean builder. Original animated gate remains byte-identical to 07.
- Checkpoint: compare the raw generated panel with the constructed panel before
  selecting the kit part and assembling the gate. No paid retries or textures.

## Exact reference prompt

Use case: stylized-concept.
Asset type: isolated component reference for Meshy image-to-3D, Hexaverse lane gate modular kit round 09.
Input image is a STYLE AND PANEL PROPORTION reference only. Generate ONE single plain triangular metal plate removed from the gate, without any attached frame or machinery. A broad scalene triangular prism, approximately 1 unit tall by 0.7 units wide and 0.035 units thick. Straight three-sided silhouette, flat parallel front and rear faces, small consistent machined bevel along the perimeter. Very plain smooth light gray satin metal, manufactured-01 revision 1 palette. Front face is one completely uninterrupted flat surface. No subdivisions, no grooves, no trim, no bolts, no pipes, no braces, no connectors, no lights, no scratches, no decorative elements. All those will be separately assembled parts later.
One centered isolated object, a near-front three-quarter studio view just enough to clearly see the small uniform thickness along two edges. Whole object fully visible with generous margins, simple soft lighting, genuinely transparent background. No floor, shadow, text, labels, second object, comparison sheet or rear-view inset. Precision machined solid with clean straight edges and planar faces.
