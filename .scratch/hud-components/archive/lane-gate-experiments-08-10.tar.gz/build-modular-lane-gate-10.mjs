// Run from repo root: node .scratch/hud-components/build-modular-lane-gate-10.mjs
// Independent closed components, semantic materials, two rigid animated halves.
import fs from 'node:fs'
import * as T from '../../frontend/node_modules/three/build/three.module.js'
const ART = '.scratch/hud-components'
const PUBLIC = 'frontend/public/models/space'
const materials = {
  plate: { name: 'manufactured-01_primary-surface', pbrMetallicRoughness: { baseColorFactor: [.60,.64,.69,1], metallicFactor: .42, roughnessFactor: .38 } },
  trim: { name: 'manufactured-01_edge-metal', pbrMetallicRoughness: { baseColorFactor: [.32,.36,.40,1], metallicFactor: .65, roughnessFactor: .32 } },
  graphite: { name: 'manufactured-01_structural-recess', pbrMetallicRoughness: { baseColorFactor: [.035,.048,.063,1], metallicFactor: .4, roughnessFactor: .48 } },
  amber: { name: 'manufactured-01_utility-accent', pbrMetallicRoughness: { baseColorFactor: [.92,.43,.055,1], metallicFactor: .18, roughnessFactor: .35 }, emissiveFactor: [.35,.09,.005] },
  energy: { name: 'manufactured-01_energy', pbrMetallicRoughness: { baseColorFactor: [.20,.67,.85,1], metallicFactor: .15, roughnessFactor: .3 }, emissiveFactor: [.07,.32,.48] },
}
const geometryCache = new Map()
function box(x,y,z) { const key=`box:${x},${y},${z}`; if(!geometryCache.has(key)) geometryCache.set(key,new T.BoxGeometry(x,y,z));return geometryCache.get(key) }
function plate(points, depth, bevel=.002) {
  const key=JSON.stringify([points,depth,bevel])
  if(geometryCache.has(key))return geometryCache.get(key)
  const shape = new T.Shape(points.map(p=>new T.Vector2(...p)))
  const g = new T.ExtrudeGeometry(shape,{ depth,steps:1,bevelEnabled:true,bevelSize:bevel,bevelThickness:bevel,bevelSegments:1,curveSegments:1 })
  g.translate(0,0,-depth/2);geometryCache.set(key,g);return g
}
const boltGeometry = new T.CylinderGeometry(.0034,.0034,.0025,6,1)
boltGeometry.rotateX(Math.PI/2)
function group(name,parent) { const g=new T.Group();g.name=name;parent?.add(g);return g }
function part(name,geometry,role,parent,position=[0,0,0]) {
  const mesh=new T.Mesh(geometry);mesh.name=name;mesh.userData.role=role;mesh.position.fromArray(position);parent.add(mesh);return mesh
}
function beam(name,a,b,width,depth,role,parent,z=0) {
  const length=Math.hypot(b[0]-a[0],b[1]-a[1])
  const mesh=part(name,box(width,length,depth),role,parent,[(a[0]+b[0])/2,(a[1]+b[1])/2,z])
  mesh.rotation.z=-Math.atan2(b[0]-a[0],b[1]-a[1]);return mesh
}
const upper=[[-.04,.485],[-.307,.30],[-.061,.058]]
const middle=[[-.315,.274],[-.29,.025],[-.074,.025]]
const reflectY = points=>points.map(([x,y])=>[x,-y]).reverse()
const outlines=[upper,middle,reflectY(middle),reflectY(upper)]
function buildPanel(name,points,parent,exploded=false) {
  const assembly=group(name,parent)
  const center=points.reduce((a,p)=>[a[0]+p[0]/3,a[1]+p[1]/3],[0,0])
  const backing=points.map(p=>p.map((v,a)=>center[a]+(v-center[a])*1.035))
  part(`${name}_Backing`,plate(backing,.024,.0015),'graphite',assembly)
  const surface=part(`${name}_Plate`,plate(points,.030,.002),'plate',assembly)
  if(exploded)surface.position.z=.095
  for(let edge=0;edge<3;edge++) {
    // Trim sits outside the plate's silhouette, never across the broad faces.
    const a=backing[edge],b=backing[(edge+1)%3]
    beam(`${name}_EdgeRail${edge+1}`,a,b,.0045,.037,'trim',assembly)
  }
  for(const face of [-1,1]) for(const corner of [0,2]) {
    const p=points[corner].map((v,a)=>center[a]+(v-center[a])*.84)
    part(`${name}_${face>0?'Front':'Back'}Fastener${corner}`,boltGeometry,'trim',assembly,[p[0],p[1],face*.0185+(exploded&&face>0?.095:0)])
  }
  return assembly
}
function buildHalf(parent,exploded=false) {
  for(let i=0;i<4;i++)buildPanel(`Panel${i+1}`,outlines[i],parent,exploded)
  for(const [section,y] of [['Upper',.254],['Lower',-.254]]) {
    part(`${section}Spine`,box(.021,.445,.043),'graphite',parent,[-.032,y,0])
    for(const z of [-.025,.025]) {
      part(`${section}_${z>0?'Front':'Back'}SpineCap`,box(.016,.431,.007),'trim',parent,[-.028,y,z])
      part(`${section}_${z>0?'Front':'Back'}Emitter`,box(.0025,.399,.003),'energy',parent,[-.022,y,z+Math.sign(z)*.005])
    }
    for(const yOffset of [-.165,.165]) {
      part(`${section}_Collar${yOffset}`,box(.030,.012,.055),'graphite',parent,[-.032,y+yOffset,0])
      for(const z of [-.029,.029])part(`${section}_Utility${yOffset}_${z}`,box(.006,.007,.0018),'amber',parent,[-.033,y+yOffset,z])
    }
  }
  const connectorPoints=[[-.056,-.026],[-.012,-.026],[-.012,.026],[-.056,.026]]
  part('WaistConnector',plate(connectorPoints,.052,.004),'graphite',parent)
  for(const face of [-1,1]) {
    const faceName=face>0?'Front':'Back'
    part(`${faceName}ConnectorCover`,plate([[-.050,-.020],[-.018,-.020],[-.018,.020],[-.050,.020]],.004,.001),'trim',parent, [0,0,face*.029])
    part(`${faceName}UtilityWindow`,box(.012,.006,.002),'amber',parent,[-.034,0,face*.0325])
  }
}
const gate=group('ModularLaneGate')
const left=group('LeftHalf',gate),right=group('RightHalf',gate)
left.position.x=-.35;right.position.x=.35;right.rotation.y=Math.PI
buildHalf(left);buildHalf(right)
const exploded=group('ExplodedHalf');buildHalf(exploded,true)
const kit=group('GateParts')
// Separate representative components arranged as a compact kit for inspection.
for(const [name,outline,x] of [['LargePlate',upper,-.23],['SmallPlate',middle,.17]]) {
  const center=outline.reduce((a,p)=>[a[0]+p[0]/3,a[1]+p[1]/3],[0,0])
  part(name,plate(outline.map(p=>p.map((v,a)=>v-center[a])),.03,.002),'plate',kit,[x,.19,0])
}
part('Spine',box(.021,.28,.043),'graphite',kit,[-.31,-.16,0])
part('EdgeRail',box(.005,.28,.037),'trim',kit,[-.22,-.16,0])
part('EmitterStrip',box(.0025,.26,.003),'energy',kit,[-.15,-.16,0])
part('WaistConnector',plate([[-.022,-.026],[.022,-.026],[.022,.026],[-.022,.026]],.052,.004),'graphite',kit,[-.045,-.16,0])
part('Collar',box(.03,.012,.055),'graphite',kit,[.06,-.16,0])
part('UtilityWindow',box(.012,.006,.002),'amber',kit,[.145,-.16,0])
part('Fastener',boltGeometry,'trim',kit,[.22,-.16,0])

function topology(g) {
  const pos=g.getAttribute('position'), ids=[],weld=new Map(),edges=new Map()
  for(let i=0;i<pos.count;i++) {
    const key=[pos.getX(i),pos.getY(i),pos.getZ(i)].map(v=>Math.round(v*1e6)).join(',')
    if(!weld.has(key))weld.set(key,weld.size);ids.push(weld.get(key))
  }
  const index=g.index?Array.from(g.index.array):Array.from({length:pos.count},(_,i)=>i)
  for(let i=0;i<index.length;i+=3) for(const [a,b]of[[0,1],[1,2],[2,0]]) {
    const key=[ids[index[i+a]],ids[index[i+b]]].sort((a,b)=>a-b).join(',')
    edges.set(key,(edges.get(key)??0)+1)
  }
  const invalid=[...edges.values()].filter(n=>n!==2).length
  if(invalid)throw new Error(`${invalid} open/non-manifold edges`)
  return index.length/3
}
function exportGLB(root,name,animated=false) {
  const doc={asset:{version:'2.0',generator:'Hexaverse modular gate builder 10'},scene:0,scenes:[{nodes:[0]}],nodes:[],meshes:[],materials:Object.values(materials),accessors:[],bufferViews:[],buffers:[{byteLength:0}],extras:{styleProfile:'manufactured-01',styleRevision:1,construction:'Separate closed manufactured parts. Flat panels and matching front/back details. No generated mesh fragments.',height:1,openGap:.70,closedGap:.012}}
  const chunks=[],geo=new Map(),meshes=new Map();let offset=0
  function append(array,type,target) {
    const pad=(4-offset%4)%4;if(pad){chunks.push(Buffer.alloc(pad));offset+=pad}
    const data=Buffer.from(array.buffer,array.byteOffset,array.byteLength)
    const view=doc.bufferViews.length;doc.bufferViews.push({buffer:0,byteOffset:offset,byteLength:data.length,...(target?{target}:{})});chunks.push(data);offset+=data.length
    const size={SCALAR:1,VEC3:3}[type]
    const accessor={bufferView:view,componentType:array instanceof Float32Array?5126:5125,count:array.length/size,type}
    if(type==='VEC3') {accessor.min=[Infinity,Infinity,Infinity];accessor.max=[-Infinity,-Infinity,-Infinity];for(let i=0;i<array.length;i++){const a=i%3;accessor.min[a]=Math.min(accessor.min[a],array[i]);accessor.max[a]=Math.max(accessor.max[a],array[i])}}
    const id=doc.accessors.length;doc.accessors.push(accessor);return id
  }
  const matKeys=Object.keys(materials)
  let triangles=0,partCount=0;const roles={}
  function visit(object) {
    const id=doc.nodes.length,node={name:object.name};doc.nodes.push(node)
    if(object.position.lengthSq())node.translation=object.position.toArray()
    if(object.quaternion.angleTo(new T.Quaternion())>1e-7)node.rotation=object.quaternion.toArray()
    if(object.isMesh) {
      const g=object.geometry,role=object.userData.role
      triangles+=topology(g);partCount++;roles[role]=(roles[role]??0)+1
      if(!geo.has(g.uuid)) {
        const attributes={POSITION:append(g.getAttribute('position').array,'VEC3',34962),NORMAL:append(g.getAttribute('normal').array,'VEC3',34962)}
        geo.set(g.uuid,{attributes,...(g.index?{indices:append(new Uint32Array(g.index.array),'SCALAR',34963)}:{})})
      }
      const key=g.uuid+role
      if(!meshes.has(key)) {meshes.set(key,doc.meshes.length);doc.meshes.push({name:object.name,primitives:[{...geo.get(g.uuid),material:matKeys.indexOf(role)}]})}
      node.mesh=meshes.get(key)
    }
    if(object.children.length)node.children=object.children.map(visit)
    return id
  }
  visit(root)
  if(animated) {
    const times=append(new Float32Array([0,1.5]),'SCALAR');doc.accessors[times].min=[0];doc.accessors[times].max=[1.5]
    const channels=[],samplers=[]
    for(const [name,sign] of [['LeftHalf',-1],['RightHalf',1]]) {
      const node=doc.nodes.findIndex(n=>n.name===name)
      const output=append(new Float32Array([sign*.006,0,0,sign*.35,0,0]),'VEC3')
      samplers.push({input:times,output,interpolation:'LINEAR'});channels.push({sampler:samplers.length-1,target:{node,path:'translation'}})
    }
    doc.animations=[{name:'Open',channels,samplers}]
  }
  doc.buffers[0].byteLength=offset
  let json=Buffer.from(JSON.stringify(doc));json=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,32)])
  const binary=Buffer.concat(chunks),header=Buffer.alloc(20),binHeader=Buffer.alloc(8)
  header.writeUInt32LE(0x46546c67);header.writeUInt32LE(2,4);header.writeUInt32LE(28+json.length+binary.length,8);header.writeUInt32LE(json.length,12);header.writeUInt32LE(0x4e4f534a,16)
  binHeader.writeUInt32LE(binary.length);binHeader.writeUInt32LE(0x004e4942,4)
  const bytes=Buffer.concat([header,json,binHeader,binary])
  for(const directory of[ART,PUBLIC])fs.writeFileSync(`${directory}/${name}.glb`,bytes)
  return {file:`${name}.glb`,triangles,parts:partCount,uniqueMeshes:doc.meshes.length,roles,bytes:bytes.length,boundaryEdges:0,nonManifoldEdges:0}
}
const stats={assembly:exportGLB(gate,'lane-gate-modular-10',true),parts:exportGLB(kit,'lane-gate-parts-10'),exploded:exportGLB(exploded,'lane-gate-exploded-10')}
// Verify the rigid halves leave a positive aperture throughout the animation.
for(const gap of [.012,.356,.70]) {
  left.position.x=-gap/2;right.position.x=gap/2;gate.updateMatrixWorld(true)
  const l=new T.Box3().setFromObject(left),r=new T.Box3().setFromObject(right)
  if(r.min.x<=l.max.x)throw new Error('Halves collide')
}
fs.writeFileSync(`${ART}/lane-gate-modular-10.stats.json`,JSON.stringify(stats,null,2)+'\n')
console.log(JSON.stringify(stats,null,2))
