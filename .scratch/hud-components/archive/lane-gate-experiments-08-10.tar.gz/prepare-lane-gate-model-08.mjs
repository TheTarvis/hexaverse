// Run from the repository root. Rebuild the rear from the existing front shell.
// The raw generation and prepared round 07 remain untouched.
import fs from 'node:fs'
import * as THREE from '../../frontend/node_modules/three/build/three.module.js'

const art = new URL('./', import.meta.url)
const source = fs.readFileSync(new URL('lane-gate-model-07.glb', art))
const jsonLength = source.readUInt32LE(12)
const doc = JSON.parse(source.subarray(20, 20 + jsonLength))
const original = source.subarray(28 + jsonLength)
const chunks = [original]
let byteLength = original.length
function read(id) {
  const a = doc.accessors[id], v = doc.bufferViews[a.bufferView]
  const size = { SCALAR: 1, VEC2: 2, VEC3: 3 }[a.type]
  const stride = v.byteStride ?? size * 4
  const start = (v.byteOffset ?? 0) + (a.byteOffset ?? 0)
  return Array.from({ length: a.count }, (_, i) => Array.from({ length: size }, (_, j) =>
    a.componentType === 5126 ? original.readFloatLE(start + i * stride + j * 4) : original.readUInt32LE(start + i * stride + j * 4)))
}
function append(rows, type, indices = false) {
  const pad = (4 - byteLength % 4) % 4
  chunks.push(Buffer.alloc(pad)); byteLength += pad
  const data = Buffer.alloc(rows.length * rows[0].length * 4)
  rows.flat().forEach((value, i) => indices ? data.writeUInt32LE(value, i * 4) : data.writeFloatLE(value, i * 4))
  const bufferView = doc.bufferViews.length
  doc.bufferViews.push({ buffer: 0, byteOffset: byteLength, byteLength: data.length, target: indices ? 34963 : 34962 })
  byteLength += data.length; chunks.push(data)
  const id = doc.accessors.length
  doc.accessors.push({ bufferView, componentType: indices ? 5125 : 5126, count: rows.length, type,
    min: rows[0].map((_, a) => rows.reduce((m, p) => Math.min(m, p[a]), Infinity)),
    max: rows[0].map((_, a) => rows.reduce((m, p) => Math.max(m, p[a]), -Infinity)) })
  return id
}
const statistics = {}
for (const mesh of doc.meshes) {
  const primitive = mesh.primitives[0]
  const positions = read(primitive.attributes.POSITION)
  const normals = read(primitive.attributes.NORMAL)
  const uvs = read(primitive.attributes.TEXCOORD_0)
  const indices = read(primitive.indices).flat()
  const bounds = [0, 1].map(a => [Math.min(...positions.map(p => p[a])), Math.max(...positions.map(p => p[a]))])
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions.flat(), 3))
  geometry.setIndex(indices)
  const material = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide })
  const object = new THREE.Mesh(geometry, material)
  object.updateMatrixWorld()
  // Retain the visible front skin, then extrude it into thin closed panels.
  // This gives the rear precisely the front's geometry and UV finish without
  // reflecting the generator's irregular rear relief into the replacement.
  const ray = new THREE.Raycaster(new THREE.Vector3(), new THREE.Vector3(0, 0, -1))
  const outP=[],outN=[],outUV=[],outI=[]
  const thickness=0.025
  const selected=[]
  for(let i=0;i<indices.length;i+=3) {
    const tri=indices.slice(i,i+3),a=new THREE.Vector3(...positions[tri[0]]),b=new THREE.Vector3(...positions[tri[1]]),c=new THREE.Vector3(...positions[tri[2]])
    const face=b.clone().sub(a).cross(c.clone().sub(a))
    if(face.z<=1e-12) continue
    const center=a.clone().add(b).add(c).multiplyScalar(1/3)
    ray.ray.origin.set(center.x,center.y,1)
    const hits=ray.intersectObject(object)
    if(!hits.length || hits[0].point.z-center.z>0.00002) continue
    selected.push(tri)
  }
  const cache=new Map(),edges=new Map()
  function emit(index,back) {
    const key=index+':'+back
    if(cache.has(key))return cache.get(key)
    const p=[...positions[index]],n=[...normals[index]]
    if(back){p[2]-=thickness;for(let i=0;i<3;i++)n[i]=-n[i]}
    const id=outP.length;outP.push(p);outN.push(n);outUV.push(uvs[index]);cache.set(key,id);return id
  }
  const pointKey=i=>positions[i].map(a=>a.toFixed(6)).join(',')
  for(const tri of selected) {
    outI.push(...tri.map(i=>[emit(i,false)]))
    outI.push(...[tri[0],tri[2],tri[1]].map(i=>[emit(i,true)]))
    for(let j=0;j<3;j++) {
      const a=tri[j],b=tri[(j+1)%3],ka=pointKey(a),kb=pointKey(b),key=[ka,kb].sort().join('|')
      if(edges.has(key))edges.delete(key)
      else edges.set(key,[a,b])
    }
  }
  // Every boundary of the visible skin receives a side wall, including tiny
  // occlusion boundaries around raised front details. Weld across atlas seams.
  for(const [a,b] of edges.values()) {
    const pa=positions[a],pb=positions[b]
    const n=new THREE.Vector3(pb[1]-pa[1],pa[0]-pb[0],0).normalize().toArray()
    const base=outP.length
    outP.push([...pa],[...pa.slice(0,2),pa[2]-thickness],[...pb.slice(0,2),pb[2]-thickness],[...pb])
    outN.push(n,n,n,n);outUV.push(uvs[a],uvs[a],uvs[b],uvs[b])
    outI.push([base],[base+1],[base+2],[base],[base+2],[base+3])
  }
  const frontTriangles=selected.length
  primitive.attributes={POSITION:append(outP,'VEC3'),NORMAL:append(outN,'VEC3'),TEXCOORD_0:append(outUV,'VEC2')}
  primitive.indices=append(outI,'SCALAR',true)
  statistics[mesh.name]={triangles:outI.length/3,vertices:outP.length,frontTriangles}
  geometry.dispose();material.dispose()
}
doc.asset.generator='Hexaverse rear-shell cleanup 08; visible front shell with matching extruded rear'
doc.extras.rearCleanup='Rear rebuilt from visible front geometry and UVs with 0.025 model-unit panel thickness; original rigid nodes, Open clip and material atlas preserved.'
doc.buffers[0].byteLength=byteLength
let json=Buffer.from(JSON.stringify(doc));json=Buffer.concat([json,Buffer.alloc((4-json.length%4)%4,32)])
let bin=Buffer.concat(chunks);bin=Buffer.concat([bin,Buffer.alloc((4-bin.length%4)%4)])
const header=Buffer.alloc(20);header.writeUInt32LE(0x46546c67);header.writeUInt32LE(2,4);header.writeUInt32LE(28+json.length+bin.length,8);header.writeUInt32LE(json.length,12);header.writeUInt32LE(0x4e4f534a,16)
const binHeader=Buffer.alloc(8);binHeader.writeUInt32LE(bin.length);binHeader.writeUInt32LE(0x004e4942,4)
const output=Buffer.concat([header,json,binHeader,bin])
fs.writeFileSync(new URL('lane-gate-model-08.glb',art),output)
fs.writeFileSync(new URL('../../frontend/public/models/space/lane-gate.glb',art),output)
fs.writeFileSync(new URL('lane-gate-model-08.stats.json',art),JSON.stringify(statistics,null,2)+'\n')
console.log(statistics)
